---
description: Lint HTML and CSS files for syntax errors and best practices using htmlhint and stylelint.
---

1. Run HTML linter on all HTML files in the project.
// turbo
Run `npx htmlhint "**/*.html"`

2. Run CSS linter on all CSS files in the project.
// turbo
Run `npx stylelint "**/*.css" --allow-empty-input`
