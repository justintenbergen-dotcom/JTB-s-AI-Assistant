---
description: Format all supported code files in the project using Prettier.
---

1. Run Prettier to format all HTML, CSS, JavaScript, and JSON files in the project workspace.
// turbo
Run `npx prettier --write "**/*.{html,css,js,json}"`
