---
description: Start the development server with auto-refresh mechanism (live-server) to automatically refresh the browser page after every edit.
---

1. Run the development server in the background
// turbo
Run `npx live-server --port=8080 --no-browser` using `run_command` with `WaitMsBeforeAsync` set to a small value (e.g., 2000) so it runs in the background.

2. Verify the server is running by waiting briefly and checking its status using `command_status`.
